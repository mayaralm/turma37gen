package com.primeiraaplicacao.aplicacao1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aplicacao1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
