package com.segundaaplicacao.aplicacao2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aplicacao2Application {

	public static void main(String[] args) {
		SpringApplication.run(Aplicacao2Application.class, args);
	}

}
